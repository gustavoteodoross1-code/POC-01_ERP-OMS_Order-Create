import com.sap.gateway.ip.core.customdev.util.Message

Message processData(Message message) {
    def h = message.getHeaders()
    def corr = (h.get("X-Correlation-Id") ?: "").toString().trim()
    if (!corr) {
        def mplId = h.get("SAP_MessageProcessingLogID")
        message.setHeader("X-Correlation-Id", mplId)
    }
    // opcional: log como propriedade customizada
    message.setProperty("correlationId", message.getHeader("X-Correlation-Id", String))
    return message
}
