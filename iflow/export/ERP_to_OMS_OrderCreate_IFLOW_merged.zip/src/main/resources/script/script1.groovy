// SetCorrelationId.groovy (compatível com API do runtime)
import com.sap.gateway.ip.core.customdev.util.Message
import java.util.UUID
import java.time.Instant

Message processData(Message message) {
    // 1) Lê o CID do header (API correta) ou gera um novo
    String cid = message.getHeader("X-Correlation-Id", String)
    if (cid == null || cid.trim().isEmpty()) {
        cid = "iflow-" + UUID.randomUUID().toString()
        message.setHeader("X-Correlation-Id", cid)
    }

    // 2) Garante Content-Type
    message.setHeader("Content-Type", "application/json")

    // 3) Propriedades para rastreio no Monitor/MPL
    message.setProperty("SAP_ApplicationID", cid)
    message.setProperty("correlationId", cid)
    message.setHeader("SAP_ApplicationID", cid)
    message.setProperty("tsEpochMs", Long.valueOf(Instant.now().toEpochMilli()))

    return message
}
